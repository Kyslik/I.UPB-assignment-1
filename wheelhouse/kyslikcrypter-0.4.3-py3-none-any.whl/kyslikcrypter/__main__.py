from .kyslikcrypter import main
main()
