#!/usr/bin/env python
# encoding: utf-8

# VARS = --none--
manifest_file_string = "recursive-include docs *"
